# Increasing-Real-Estate-Management-Profits-Harnessing-Data-Analytics
Capstone Project
