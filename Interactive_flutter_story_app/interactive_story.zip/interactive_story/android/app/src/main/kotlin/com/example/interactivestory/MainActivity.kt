package com.example.interactivestory

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
